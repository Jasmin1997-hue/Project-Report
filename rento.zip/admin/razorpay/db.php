<?php
$con=mysqli_connect('host','username','password','dbname');
?>